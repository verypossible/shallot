
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.2.2'
version = '1.2.2'
full_version = '1.2.2'
git_revision = '600e7f576a1165026b1879ce708d8efb7cbc8109'
release = True

if not release:
    version = full_version
